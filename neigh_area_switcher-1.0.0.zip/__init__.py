import bpy
from bpy.types import Operator

class SCREEN_OT_area_switcher(Operator):
    bl_idname = "screen.area_switcher"
    bl_label = "Area Switcher"
    bl_description = "Open the area type switcher at the mouse cursor location"
    bl_options = {'REGISTER', 'UNDO'}

    def draw(self, context):
        layout = self.layout
        
        area_types = {
            "General": [
                ('VIEW_3D', "3D Viewport", 'VIEW3D'),
                ('IMAGE_EDITOR', "Image Editor", 'IMAGE'),
                ('UV', "UV Editor", 'UV'),
                ('CompositorNodeTree', "Compositor", 'NODE_COMPOSITING'),
                ('TextureNodeTree', "Texture Node Editor", 'NODE_TEXTURE'),
                ('GeometryNodeTree', "Geometry Node Editor", 'NODETREE'),
                ('ShaderNodeTree', "Shader Editor", 'NODE_MATERIAL'),
                ('SEQUENCE_EDITOR', "Video Sequencer", 'SEQUENCE'),
                ('CLIP_EDITOR', "Movie Clip Editor", 'TRACKER'),
            ],
            "Animation": [
                ('DOPESHEET', "Dope Sheet", 'ACTION'),
                ('TIMELINE', "Timeline", 'TIME'),
                ('FCURVES', "Graph Editor", 'GRAPH'),
                ('DRIVERS', "Drivers", 'DRIVER'),
                ('NLA_EDITOR', "Nonlinear Animation", 'NLA'),
            ],
            "Scripting": [
                ('TEXT_EDITOR', "Text Editor", 'TEXT'),
                ('CONSOLE', "Python Console", 'CONSOLE'),
                ('INFO', "Info", 'INFO'),
            ],
            "Data": [
                ('OUTLINER', "Outliner", 'OUTLINER'),
                ('PROPERTIES', "Properties", 'PROPERTIES'),
                ('FILES', "File Browser", 'FILEBROWSER'),
                ('ASSETS', "Asset Browser", 'ASSET_MANAGER'),
                ('SPREADSHEET', "Spreadsheet", 'SPREADSHEET'),
                ('PREFERENCES', "Preferences", 'PREFERENCES'),
            ]
        }

        row = layout.row()
        for group, types in area_types.items():
            col = row.column()
            col.label(text=group)
            for identifier, name, icon in types:
                props = col.operator("wm.context_set_enum", text=name, icon=icon)
                props.data_path = "area.ui_type"
                props.value = identifier

    def invoke(self, context, event):
        return context.window_manager.invoke_popup(self, width=600)

    def execute(self, context):
        return {'FINISHED'}

def draw_menu(self, context):
    self.layout.operator(SCREEN_OT_area_switcher.bl_idname)

addon_keymaps = []

def register():
    bpy.utils.register_class(SCREEN_OT_area_switcher)
    
    # Add to View menu
    bpy.types.VIEW3D_MT_view.append(draw_menu)
    
    # Add keymap entry
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if kc:
        km = kc.keymaps.new(name='Window', space_type='EMPTY')
        kmi = km.keymap_items.new(SCREEN_OT_area_switcher.bl_idname, 'A', 'PRESS', ctrl=True, shift=True)
        addon_keymaps.append((km, kmi))

def unregister():
    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()

    bpy.types.VIEW3D_MT_view.remove(draw_menu)
    bpy.utils.unregister_class(SCREEN_OT_area_switcher)

if __name__ == "__main__":
    register()